
#include "Song.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

   Song::Song() // default constructor
   {
      artist ="";
      title ="";
      memory =0;
   }
   Song::Song(string _artist, string _title, int _memory)// constructor
   {
     
      artist=_artist;
      title =_title;
      memory=_memory;
       
   }
string Song::getArtist() const
{ return artist; }

void Song:: setArtist(string a)
{
   artist = a;
}
string Song::getTitle() const
{return title;}

void Song::setTitle(string b) 
{
   title = b;
}

int Song:: getMemory() const
{return memory;}

void Song::setMemory(int m)
{
    memory =m;
}

bool Song::operator==(Song const &rhs){
   return(artist ==rhs.artist && title ==rhs.title && memory ==rhs.memory);
}
bool Song::operator>(Song const &rhs)
{
   bool status;
if(artist >rhs.artist){
   status =true;
}
if (artist ==rhs.artist){
   if(title>rhs.title)
      status =true;
 else  if(title==rhs.title){
      if(memory>rhs.memory)
         status =true;
         if (memory==rhs.memory)
            status =false;
    }else
        status =false;
   }else
       status =false;
  return status;
}

bool Song::operator<(Song const &rhs)
{
   bool status;
if(artist <rhs.artist){
   status =true;
}
if (artist ==rhs.artist){
   if(title<rhs.title)
      status =true;
  else if(title==rhs.title){
      if(memory<rhs.memory)
         status =true;
         if (memory==rhs.memory)
            status =false;
    }else
        status =false;
   }else
       status =false;
  return status;
}
bool Song::operator!=(Song const &rhs){
   return(artist !=rhs.artist || title !=rhs.title || memory !=rhs.memory);
}
   
