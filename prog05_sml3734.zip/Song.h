
#ifndef SONG_H
#define SONG_H
#include <string>
#include <iostream>
using namespace std;

class Song{
    private:
        string artist;
        string title;
        int memory;
    public:
        Song(); //default constructor
        Song(string artist, string title, int memory); //constructor

        string getTitle()const;
        
        void setTitle(string n);
        string getArtist() const;
        void setArtist(string m);
        int getMemory() const;
        void setMemory(int h);
        bool operator ==(Song const &rhs);
        bool operator >(Song const &rhs);
        bool operator <(Song const &rhs);
        bool operator !=(Song const &rhs);

  // ~Song(); //destractor
};


#endif


