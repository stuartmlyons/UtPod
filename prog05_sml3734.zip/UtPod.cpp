
#include "UtPod.h"
#include <fstream>
#include <iostream>
#include <ctime>
#include <stdlib.h>
using namespace std;

UtPod::UtPod()
{
   songs =NULL; //initialize linked list
   memSize =MAX_MEMORY; 
}
UtPod::UtPod(int size)
{
	songs =NULL;
        if (size>MAX_MEMORY || size<=0){
	memSize=MAX_MEMORY;
        }else {
		memSize =size;
		}
}
int UtPod::addSong(Song const &s){
   if(s.getTitle()=="" || s.getArtist()=="" || s.getMemory()>getRemainingMemory()){
   return NO_MEMORY;// checking for valid input
      }
   SongNode *newNode;
   SongNode *nodePtr; 
   newNode=new SongNode;
   newNode->s =Song(s.getArtist(), s.getTitle(), s.getMemory());// constructor by default
   newNode->next =NULL;
   if(!songs) // checking if there is no nodes in the list
      songs=newNode;
   else // otherwise insert node at the end
{
   nodePtr=songs;
   while(nodePtr->next)
      nodePtr=nodePtr->next;
      nodePtr->next=newNode;
   }
return SUCCESS;//0 
}
int UtPod::removeSong(Song const &s){
   SongNode *nodePtr;//create a pointer to traverse the list
   SongNode *currentNode;
   SongNode *previousNode;// to point to the previous node
   if (songs==NULL)//empty list
   	return NOT_FOUND;//-2
  /// nodePtr =songs;
   if(songs->s==s)
   {
       nodePtr=songs->next;
       delete songs;
       songs=nodePtr;
       return SUCCESS;
   }
      else
      {
      nodePtr=songs;
      while(nodePtr!=NULL && nodePtr->s!=s)
      {
         previousNode=nodePtr;
         nodePtr=nodePtr->next;
      }
      if(nodePtr)
      {
       previousNode->next=nodePtr->next;
       delete nodePtr;
       return SUCCESS;
       }
    }
    return NOT_FOUND;
}
  
void UtPod::shuffle(){
   SongNode *nodePtr;
   SongNode *p1;
   SongNode *p2;
   nodePtr=songs;
   Song temp;
   int ListNum=0;
   while(nodePtr)
      {
         ListNum=ListNum+1;
         nodePtr=nodePtr->next;
      }
  // unsigned int currentTime=42;
   time_t t;
   srand((unsigned)time(&t));
  // srand(currentTime);//seed the random number generator
   nodePtr=songs;
 //  p1=nodePtr;
   for(int i=0; i<ListNum; i++){
       int node1=(rand()%ListNum);
       int node2=(rand()%ListNum);
   nodePtr=songs;
   p1=nodePtr;   
   for (int i=0; i<node1; i++){
      nodePtr=nodePtr->next;
      p1=nodePtr;}
   nodePtr=songs;
   p2=nodePtr;
   for (int i=0; i<node2; i++){
      nodePtr=nodePtr->next;
      p2=nodePtr;}
   
   temp =p1->s;
   p1->s =p2->s;
   p2->s =temp; 
   }
}
void UtPod::showSongList(){

   SongNode *nodePtr;// pointer to traverse the list
   nodePtr= songs;// position at the head of the list
   while(nodePtr){
   cout<<nodePtr->s.getArtist()<<"   | "<<nodePtr->s.getTitle()<<"   "<<nodePtr->s.getMemory()<<endl;
   nodePtr=nodePtr->next;
   }
}


void UtPod::sortSongList(){
   SongNode *nodePtr;
   nodePtr=songs;
   SongNode *p1;
   SongNode *p2;
   Song temp;//temporary node to hold value for swap
int ListNum=0;
   while(nodePtr)
   {
      ListNum=ListNum+1;
      nodePtr=nodePtr->next;
    }
  for (int i=0; i<(ListNum-1); i++){
      nodePtr=songs;
       for(int j=i+1; j<ListNum; j++){
          if(nodePtr->s > nodePtr->next->s){
             p1=nodePtr;
            p2=nodePtr->next;
            temp =p1->s;
             p1->s=p2->s;
            p2->s =temp;}
            nodePtr=nodePtr->next;
          }

      }
 
}
void UtPod::clearMemory(){
 SongNode *nodePtr;
   SongNode *nextNode;
   nodePtr =songs; //position at the head
   while(nodePtr!=NULL)
      {
      nextNode=nodePtr->next; //save pointer to the next node
      delete nodePtr;// delete the current node
      nodePtr=nextNode; //position at the next node
      }

}
//int UtPod::getTotalMemory(){
//}
int UtPod::getRemainingMemory(){
   SongNode *nodePtr;
   nodePtr =songs;
   int TotalMem=0;
   while(nodePtr)
   {
      TotalMem=TotalMem+(nodePtr->s.getMemory());
      nodePtr=nodePtr->next;
    }
    return (memSize-TotalMem);   
}
 UtPod::~UtPod(){// destroying the list
   SongNode *nodePtr;
   SongNode *nextNode;
   nodePtr =songs; //position at the head
   while(nodePtr!=NULL)
      {
      nextNode=nodePtr->next; //save pointer to the next node
      delete nodePtr;// delete the current node
      nodePtr=nextNode; //position at the next node
      }
}


